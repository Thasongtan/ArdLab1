

#include <avr/io.h>
#define F_CPU 16000000UL
#include "util/delay.h"


int main(void)
{
    DDRC = 0b00000011;
	DDRB = 0x00;
	PORTC = 0b00000000;
	PORTB =0x01;
	while(1)
	{
		PORTC = 0b00000001;
		_delay_ms(500);
		PORTC = 0x02;
		_delay_ms(500);
		while ((PINB&0x01)==0){
			PORTC = 0x00;
		}
	}
}

